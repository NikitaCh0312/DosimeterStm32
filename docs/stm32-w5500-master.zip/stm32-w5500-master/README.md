# stm32-w5500
STM32: example of usage of Wiznet W5500 Ethernet controller
